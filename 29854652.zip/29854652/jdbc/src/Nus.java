import java.sql.*;
import java.util.Scanner;
import java.util.UUID;

public class Nus {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/courier_tracking";
    private static final String USER = "root";
    private static final String PASSWORD = "Tushar.slrn@123";

    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Error loading MySQL JDBC driver: " + e.getMessage());
            return;
        }

        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("Courier Tracking System");
            System.out.println("1. Register New Parcel");
            System.out.println("2. Track Parcel");
            System.out.println("3. Manage Delivery Status");
            System.out.println("4. Manage Customer Information");
            System.out.println("5. Assign Parcel to Customer");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    registerNewParcel(scanner);
                    break;
                case 2:
                    trackParcel(scanner);
                    break;
                case 3:
                    manageDeliveryStatus(scanner);
                    break;
                case 4:
                    manageCustomerInformation(scanner);
                    break;
                case 5:
                    assignParcelToCustomer(scanner);
                    break;
                case 6:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }

    private static void registerNewParcel(Scanner scanner) {
        System.out.print("Enter sender name: ");
        String senderName = scanner.nextLine();
        System.out.print("Enter sender address: ");
        String senderAddress = scanner.nextLine();
        System.out.print("Enter recipient name: ");
        String recipientName = scanner.nextLine();
        System.out.print("Enter recipient address: ");
        String recipientAddress = scanner.nextLine();

        String trackingNumber = UUID.randomUUID().toString();

        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASSWORD)) {
            String query = "INSERT INTO parcels (tracking_number, sender_name, sender_address, recipient_name, recipient_address, current_status, delivery_history) VALUES (?, ?, ?, ?, ?, 'Registered', '')";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, trackingNumber);
            preparedStatement.setString(2, senderName);
            preparedStatement.setString(3, senderAddress);
            preparedStatement.setString(4, recipientName);
            preparedStatement.setString(5, recipientAddress);

            int rowsInserted = preparedStatement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Parcel registered successfully. Tracking number: " + trackingNumber);
            } else {
                System.out.println("Failed to register parcel.");
            }
        } catch (SQLException e) {
            System.out.println("Error registering parcel: " + e.getMessage());
        }
    }

    private static void trackParcel(Scanner scanner) {
        System.out.print("Enter parcel tracking number: ");
        String trackingNumber = scanner.nextLine();

        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASSWORD)) {
            String query = "SELECT * FROM parcels WHERE tracking_number = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, trackingNumber);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Parcel ID: " + resultSet.getInt("parcel_id"));
                System.out.println("Sender Name: " + resultSet.getString("sender_name"));
                System.out.println("Sender Address: " + resultSet.getString("sender_address"));
                System.out.println("Recipient Name: " + resultSet.getString("recipient_name"));
                System.out.println("Recipient Address: " + resultSet.getString("recipient_address"));
                System.out.println("Current Status: " + resultSet.getString("current_status"));
                System.out.println("Delivery History: " + resultSet.getString("delivery_history"));
            } else {
                System.out.println("No parcel found with the given tracking number.");
            }
        } catch (SQLException e) {
            System.out.println("Error tracking parcel: " + e.getMessage());
        }
    }

    private static void manageDeliveryStatus(Scanner scanner) {
        System.out.print("Enter parcel tracking number: ");
        String trackingNumber = scanner.nextLine();

        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASSWORD)) {
            String query = "SELECT * FROM parcels WHERE tracking_number = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, trackingNumber);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                System.out.print("Enter new delivery status: ");
                String newStatus = scanner.nextLine();

                String updateQuery = "UPDATE parcels SET current_status = ?, delivery_history = CONCAT(delivery_history, ?) WHERE tracking_number = ?";
                PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
                updateStatement.setString(1, newStatus);
                updateStatement.setString(2, newStatus + ", ");
                updateStatement.setString(3, trackingNumber);

                int rowsUpdated = updateStatement.executeUpdate();
                if (rowsUpdated > 0) {
                    System.out.println("Delivery status updated successfully.");
                } else {
                    System.out.println("Failed to update delivery status.");
                }
            } else {
                System.out.println("No parcel found with the given tracking number.");
            }
        } catch (SQLException e) {
            System.out.println("Error updating delivery status: " + e.getMessage());
        }
    }

    private static void manageCustomerInformation(Scanner scanner) {
        System.out.println("Customer Information Management");
        System.out.println("1. Register New Customer");
        System.out.println("2. View Customer Details");
        System.out.println("3. Update Customer Information");
        System.out.println("4. Delete Customer Account");
        System.out.print("Choose an option: ");

        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                registerNewCustomer(scanner);
                break;
            case 2:
                viewCustomerDetails(scanner);
                break;
            case 3:
                updateCustomerInformation(scanner);
                break;
            case 4:
                deleteCustomerAccount(scanner);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void registerNewCustomer(Scanner scanner) {
        System.out.print("Enter customer name: ");
        String name = scanner.nextLine();
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        System.out.print("Enter phone number: ");
        String phoneNumber = scanner.nextLine();

        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASSWORD)) {
            String query = "INSERT INTO customers (customer_name, email, phone_number) VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, phoneNumber);

            int rowsInserted = preparedStatement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Customer registered successfully.");
            } else {
                System.out.println("Failed to register customer.");
            }
        } catch (SQLException e) {
            System.out.println("Error registering customer: " + e.getMessage());
        }
    }

    private static void viewCustomerDetails(Scanner scanner) {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();

        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASSWORD)) {
            String query = "SELECT * FROM customers WHERE customer_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, customerId);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Customer ID: " + resultSet.getInt("customer_id"));
                System.out.println("Customer Name: " + resultSet.getString("customer_name"));
                System.out.println("Email: " + resultSet.getString("email"));
                System.out.println("Phone Number: " + resultSet.getString("phone_number"));
            } else {
                System.out.println("No customer found with the given ID.");
            }
        } catch (SQLException e) {
            System.out.println("Error viewing customer details: " + e.getMessage());
        }
    }

    private static void updateCustomerInformation(Scanner scanner) {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter new customer name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new email: ");
        String email = scanner.nextLine();
        System.out.print("Enter new phone number: ");
        String phoneNumber = scanner.nextLine();

        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASSWORD)) {
            String query = "UPDATE customers SET customer_name = ?, email = ?, phone_number = ? WHERE customer_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, phoneNumber);
            preparedStatement.setInt(4, customerId);

            int rowsUpdated = preparedStatement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Customer information updated successfully.");
            } else {
                System.out.println("Failed to update customer information.");
            }
        } catch (SQLException e) {
            System.out.println("Error updating customer information: " + e.getMessage());
        }
    }

    private static void deleteCustomerAccount(Scanner scanner) {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();

        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASSWORD)) {
            String query = "DELETE FROM customers WHERE customer_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, customerId);

            int rowsDeleted = preparedStatement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Customer account deleted successfully.");
            } else {
                System.out.println("Failed to delete customer account.");
            }
        } catch (SQLException e) {
            System.out.println("Error deleting customer account: " + e.getMessage());
        }
    }

    private static void assignParcelToCustomer(Scanner scanner) {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter parcel tracking number: ");
        String trackingNumber = scanner.nextLine();

        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASSWORD)) {
            String query = "SELECT parcel_id FROM parcels WHERE tracking_number = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, trackingNumber);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int parcelId = resultSet.getInt("parcel_id");

                String insertQuery = "INSERT INTO CustomerParcels (customer_id, parcel_id) VALUES (?, ?)";
                PreparedStatement insertStatement = connection.prepareStatement(insertQuery);
                insertStatement.setInt(1, customerId);
                insertStatement.setInt(2, parcelId);

                int rowsInserted = insertStatement.executeUpdate();
                if (rowsInserted > 0) {
                    System.out.println("Parcel assigned to customer successfully.");
                } else {
                    System.out.println("Failed to assign parcel to customer.");
                }
            } else {
                System.out.println("No parcel found with the given tracking number.");
            }
        } catch (SQLException e) {
            System.out.println("Error assigning parcel to customer: " + e.getMessage());
        }
    }
}
